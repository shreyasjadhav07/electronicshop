package ElectronicShop.electronicShop.api;

import com.electronicShop.electronicShop.api.LaptopApi;
import io.swagger.annotations.Api;
import org.springframework.stereotype.Controller;

@Controller
@Api(tags = "Laptop")
public class LaptopController implements LaptopApi {
}
