package ElectronicShop.electronicShop.api;

import com.electronicShop.electronicShop.api.MobileApi;
import io.swagger.annotations.Api;
import org.springframework.stereotype.Controller;

@Controller
@Api(tags = "Mobile")
public class MobileController implements MobileApi {
}
