package ElectronicShop.electronicShop.api;

import com.electronicShop.electronicShop.api.BillingApi;
import io.swagger.annotations.Api;
import org.springframework.stereotype.Controller;

@Controller
@Api(tags = "Billing")
public class BillingController implements BillingApi {
}
