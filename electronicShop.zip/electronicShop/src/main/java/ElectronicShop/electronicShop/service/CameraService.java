package ElectronicShop.electronicShop.service;

import org.springframework.stereotype.Component;

@Component
public class CameraService {
}
