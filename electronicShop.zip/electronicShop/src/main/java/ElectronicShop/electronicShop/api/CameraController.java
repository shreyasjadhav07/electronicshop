package ElectronicShop.electronicShop.api;

import ElectronicShop.electronicShop.service.CameraService;
import com.electronicShop.electronicShop.api.CameraApi;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Api(tags = "Camera")
public class CameraController implements CameraApi {
    @Autowired
    private CameraService cameraService;
}
