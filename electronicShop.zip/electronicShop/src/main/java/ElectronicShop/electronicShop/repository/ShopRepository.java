package ElectronicShop.electronicShop.repository;

import ElectronicShop.electronicShop.entity.Shop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopRepository extends JpaRepository<Shop,Integer> {
}
