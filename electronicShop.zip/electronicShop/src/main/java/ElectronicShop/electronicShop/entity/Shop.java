package ElectronicShop.electronicShop.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;
import java.util.Queue;
import java.util.Set;

@Entity
@Data
public class Shop {
    @Id
    private int shopId;
    private String shopName;
    private int shopNumber;
    private String shopAdress;
    @OneToMany(mappedBy = "shop",fetch = FetchType.LAZY)
    private List<Employee> employee;
    @OneToMany(mappedBy = "shop",fetch = FetchType.EAGER)
    private List<Laptop> laptop;
    @OneToMany(mappedBy = "shop",fetch = FetchType.LAZY)
    private  Set<Camera> camera;
    @OneToMany(mappedBy = "shop",fetch = FetchType.EAGER)
    private Set<Mobile> mobile;


}
