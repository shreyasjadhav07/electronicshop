package ElectronicShop.electronicShop.entity;

import lombok.Data;

import javax.persistence.*;


@Entity
@Data
public class Camera {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cameraId;
    private String camerabrandName;
    private String cameraModel;
    @ManyToOne
    @JoinColumn(name = "shopId")
    private Shop shop;
    @ManyToOne
    @JoinColumn(name = "employeeId")
    private Employee employee;


}
