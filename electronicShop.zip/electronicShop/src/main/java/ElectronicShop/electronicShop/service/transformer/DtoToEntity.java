package ElectronicShop.electronicShop.service.transformer;

import ElectronicShop.electronicShop.entity.Shop;
import com.electronicShop.electronicShop.dto.ShopDto;
import org.springframework.stereotype.Component;

@Component
public class DtoToEntity {
    public Shop DtoToEntityCompany(ShopDto shopDto) {
        Shop shop = new Shop();
}
