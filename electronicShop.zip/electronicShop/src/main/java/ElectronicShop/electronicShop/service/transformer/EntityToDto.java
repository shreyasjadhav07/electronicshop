package ElectronicShop.electronicShop.service.transformer;

public class EntityToDto {
}
