package ElectronicShop.electronicShop.repository;

import ElectronicShop.electronicShop.entity.Mobile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MobileRepository extends JpaRepository<Mobile,Integer> {
}
