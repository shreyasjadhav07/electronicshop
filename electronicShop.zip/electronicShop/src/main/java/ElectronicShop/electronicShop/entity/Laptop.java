package ElectronicShop.electronicShop.entity;

import lombok.Data;

import javax.persistence.*;


@Entity
@Data
public class Laptop {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int laptopId;
    private String laptopbrandName;
    private String laptopModel;
    @ManyToOne
    @JoinColumn(name = "shopId")
    private Shop shop;
    @ManyToOne
    @JoinColumn(name = "employeeId")
    private Employee employee;

}
