package ElectronicShop.electronicShop.entity;

import lombok.Data;

import javax.persistence.*;
@Entity
@Data
public class Billing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int billingId;
    private String customerName;
    private String billingDate;
    private String deviceType;
    private long sellingprice;
    @ManyToOne
    @JoinColumn(name = "employeeId")
    private Employee employee;
}
