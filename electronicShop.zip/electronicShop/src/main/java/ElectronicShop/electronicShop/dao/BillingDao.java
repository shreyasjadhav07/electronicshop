package ElectronicShop.electronicShop.dao;

import org.springframework.stereotype.Component;

@Component
public class BillingDao {
}
