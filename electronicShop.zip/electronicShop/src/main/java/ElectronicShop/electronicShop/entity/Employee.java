package ElectronicShop.electronicShop.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Data
public class Employee {
    @Id
    private int employeeId;
    private String employeeName;
    private  String employeedesignation;
    private int employeesalary;
    private String employeejoiningdate;
    @OneToMany(mappedBy = "employee",fetch = FetchType.LAZY)
    private List<Laptop> laptop;
    @OneToMany(mappedBy = "employee",fetch = FetchType.EAGER)
    private List<Camera> camera;
    @OneToMany(mappedBy = "employee",fetch = FetchType.LAZY)
    private Set<Mobile> mobile;
    @OneToMany(mappedBy = "employee",fetch = FetchType.EAGER)
    private Set<Billing> billing;
    @ManyToOne
    @JoinColumn(name="shopId")
    private Shop shop;
}
