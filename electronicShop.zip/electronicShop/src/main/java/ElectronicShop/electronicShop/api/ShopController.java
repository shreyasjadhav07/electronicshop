package ElectronicShop.electronicShop.api;

import ElectronicShop.electronicShop.service.ShopService;
import com.electronicShop.electronicShop.api.ShopApi;
import com.electronicShop.electronicShop.dto.ShopDto;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
@Api(tags = "Shop")
public class ShopController implements ShopApi {
    @Autowired
    private ShopService shopService;

    @Override
    public ResponseEntity<ShopDto> createShop(ShopDto shopDto) throws Exception {
        return new ResponseEntity<>(shopService.save(shopDto), HttpStatus.CREATED);
    }
}
