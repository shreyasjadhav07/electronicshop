package ElectronicShop.electronicShop.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Mobile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int mobileId;
    private String mobilebrandName;
    private String mobileModel;
    @ManyToOne
    @JoinColumn(name = "shopId")
    private Shop shop;
    @ManyToOne
    @JoinColumn(name = "employeeId")
    private Employee employee;
}
