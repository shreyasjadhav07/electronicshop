package ElectronicShop.electronicShop.repository;

import ElectronicShop.electronicShop.entity.Billing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillingRepository extends JpaRepository<Billing,Integer> {
}
