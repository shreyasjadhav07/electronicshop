package ElectronicShop.electronicShop.service;

import ElectronicShop.electronicShop.entity.Shop;
import com.electronicShop.electronicShop.dto.ShopDto;
import org.springframework.stereotype.Component;

@Component
public class ShopService {
    public ShopDto save(ShopDto shopDto) {
        Shop shop = shopDao.save(dtoToEntity.DtoToEntityCompany(companyDto));
        return entityToDto.EntitytoCompanyDto(shop);
    }
}
