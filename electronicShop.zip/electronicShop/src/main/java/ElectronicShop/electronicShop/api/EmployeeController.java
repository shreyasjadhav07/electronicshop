package ElectronicShop.electronicShop.api;

import com.electronicShop.electronicShop.api.EmployeeApi;
import io.swagger.annotations.Api;
import org.springframework.stereotype.Controller;

@Controller
@Api(tags = "Employee")
public class EmployeeController implements EmployeeApi {
}
